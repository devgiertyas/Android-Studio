﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace INSS
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        private float DescontoInss(float salario)
        {
            float desconto;

            if(salario <= 1243.23){
                desconto = 0;
            }

            else if(salario >= 1243.24 && salario <= 2315.17)
            {
                desconto = (salario * 8) / 100;

                if (desconto > 600)
                    desconto = 600;
            }

            else if (salario >= 2315.17 && salario <= 3115.30)
            {
                desconto = (salario * 9) / 100;

                if (desconto > 600)
                    desconto = 600;
            }

             else 
            {
                desconto = (salario * 11) / 100;

                if (desconto > 600)
                    desconto = 600;
            }

      

            return desconto;

        }

        private float IPR(float salario)
        {
            float impostorenda;

            if (salario <= 2000)
            {
                impostorenda = 0;

            }

            else if (salario >= 2000.01f && salario <= 3000 )
            {
                impostorenda = (salario * 7.5f) / 100;


            }

            else if (salario >= 3000.01f && salario <= 4000)
            {
                impostorenda = (salario * 9.5f) / 100;


            }

            else
            {
                impostorenda = (salario * 11) / 100;

            }

            return impostorenda;

        }

        private float Descontos(float salario)
        {
            float descontos = 0;

            salario = salario - descontos;

            return descontos; 
        }

 

        protected void btnCalcular_ServerClick1(object sender, EventArgs e)
        {
            float salario = 0, descontoinss, total, impostorenda, descontos = 0;

            try
            {
                salario = float.Parse(txtSalario.Value);
                descontos = float.Parse(txtDescontos.Value);
            }
            catch
            { }

            impostorenda = IPR(salario);
            descontoinss = DescontoInss(salario);
            Descontos(salario);

            total = salario - descontoinss - impostorenda - descontos ;
      
            txtSalarioLiquido.Value = ("Salário liquido "+ total.ToString("C2"));
            txtDescontoInss.Value = ("Desconto INSS " + descontoinss.ToString("C2"));
            txtDescontoIR.Value = ("Desconto IR " + impostorenda.ToString("C2"));
            txtDescontoview.Value = ("Descontos " + descontos.ToString("C2"));
        }
    }
}