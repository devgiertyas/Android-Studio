﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Npgsql;
using System.Data;

namespace DataBase
{
    public class Produto
    {
        public int id { get; set; }
        public string nome_produto { get; set; }
        public int quantidade { get; set; }
        public float valorunitario { get; set; }


        public bool GravarProduto(Produto pr)
        {
            // Cria um objeto da classe conexao
            Conexao db = new Conexao();

            // Cria um objeto de comando do postgre
            NpgsqlCommand cmd = new NpgsqlCommand();

            try
            {

                // ADCIONA A INSTRUÇÃO SQL
                cmd.CommandText = "INSERT INTO produtos (nome_produto, quantidade,valor) values(@nome_produto, @quantidade, @valor)";

                // Desine os valores que serão passados para a intrução sql
                cmd.Parameters.AddWithValue("@nome_produto", pr.nome_produto);
                cmd.Parameters.AddWithValue("@quantidade", pr.quantidade);
                cmd.Parameters.AddWithValue("@valor", pr.valorunitario);

                // Cria uma conexao com o banco
                cmd.Connection = db.OpenConnection();

                // Executa o comando Sql
                cmd.ExecuteNonQuery();

                return true;

            }
            catch
            {
                return false;

            }
            finally
            {
                // Fecha a conexao com o banco
                db.CloseConnection(cmd.Connection);

            }
        }

        public bool Deletar(Produto pr)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            Conexao db = new Conexao();

            try
            {
                cmd.CommandText = "delete from produtos where id = @id";

                cmd.Parameters.AddWithValue("@id", pr.id);

                cmd.Connection = db.OpenConnection();

                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                db.CloseConnection(cmd.Connection);
            }

        }

        public DataTable SelecionarTodos()
        {
            Conexao connect = new Conexao();
            NpgsqlCommand comando = new NpgsqlCommand();

            comando.CommandText = "select * from produtos order by id";

            comando.Connection = connect.OpenConnection();

            DataTable dadosprodutos = new DataTable();

            dadosprodutos.Load(comando.ExecuteReader());

            connect.CloseConnection(comando.Connection);

            return dadosprodutos;


        }

        public bool EditarProduto(Produto prd)
        {
            Conexao db = new Conexao();

            NpgsqlCommand cmd = new NpgsqlCommand();


            try
            {
                cmd.CommandText = @"update produtos set nome_produto = @nome_produto ,quantidade = @quantidade, valor = @valor where id = @id";

                cmd.Parameters.AddWithValue("@id", prd.id);
                cmd.Parameters.AddWithValue("@nome_produto", prd.nome_produto);
                cmd.Parameters.AddWithValue("@quantidade", prd.quantidade);
                cmd.Parameters.AddWithValue("@valor", prd.valorunitario);


                cmd.Connection = db.OpenConnection();

                // Execução dos comandos

                cmd.ExecuteNonQuery();

                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                // Fecha o banco 
                db.CloseConnection(cmd.Connection);
            }


        }

    }
}
