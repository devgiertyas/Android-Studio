﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataBase;
using System.Data;
using System.Text;

namespace DataBase
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            CarregarDados();

        }

        protected void btnGravar_ServerClick(object sender, EventArgs e)
        {
            Produto pr = new Produto();

            pr.nome_produto = txtNomeProduto.Value;
            pr.quantidade = int.Parse(txtQuantidade.Value);
            pr.valorunitario = float.Parse(txtValorUnitario.Value);

            // Chama metodo de gravação e exibe uma mensagem
            if (pr.GravarProduto(pr))
            {

                // Mostra a caixa de mensaggem sucesso
                menssagemSucesso.Attributes.CssStyle.Add("display", "block");
            }
            else
            {
                menssagemErro.Attributes.CssStyle.Add("display", "block");
            }
            CarregarDados();

        }

        protected void BtnDeletar_ServerClick(object sender, EventArgs e)
        {
            Produto prd = new Produto();

            prd.id = int.Parse(txtId.Value);

            if (prd.Deletar(prd))
            {

                MensagemDeletado.Attributes.CssStyle.Add("display", "block");

                CarregarDados();
            }
            else {
                menssagemErroDeletado.Attributes.CssStyle.Add("display", "block");
            }
       
        }

        // Métodos para carregar os dados na interface
        private void CarregarDados()
        {
            // Cria um datatable para receber o resultado

            DataTable dt = new DataTable();

            Produto pr = new Produto();

            dt = pr.SelecionarTodos();

            // Verifica se existem dados no DataTable

            if(dt.Rows.Count > 0)
            {
                // Cria um stringBuilder para construir a tabela
                StringBuilder html = new StringBuilder();

                //Cria tag table
                html.Append("<table class='table table-striped'>");

                html.Append("<thead class='thead-dark'>");

                html.Append("<tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }
                html.Append("</tr>");
                html.Append("</thead");

                //Cria linhas da tabela
                html.Append("<tbody>");
                foreach (DataRow row in dt.Rows)
                {
                    html.Append("<tr>");
                    foreach (DataColumn coloumn in dt.Columns)
                    {
                        html.Append("<td>");
                        html.Append(row[coloumn.ColumnName]);
                        html.Append("</td>");
                    }
                    html.Append("</tr>");
                    html.Append("</tbody>");
                }
                //Fecha a tabela
                html.Append("</table>");

                //Exibe a tabela na interface
                tabela.Text = html.ToString();
            }

        }

        protected void BtnEditar_ServerClick(object sender, EventArgs e)
        {
            Produto pr = new Produto();

            pr.id = int.Parse(txtId.Value);

            pr.nome_produto = txtNomeProduto.Value;
            pr.quantidade = int.Parse(txtQuantidade.Value);
            pr.valorunitario = float.Parse(txtValorUnitario.Value);


            if (!String.IsNullOrEmpty(txtId.Value))
            {
                if (pr.EditarProduto(pr))
                {

                    menssagemEditado.Attributes.CssStyle.Add("display", "block");

                    CarregarDados();
                }
                else
                {
                    menssagemErroEditado.Attributes.CssStyle.Add("display", "block");
                }
            }
            else
            {

                msgErroCampovazio.Attributes.CssStyle.Add("display", "block");
            }

          


        }
    }
}
