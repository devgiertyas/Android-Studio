﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

namespace AgendaTelefonica
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            CarregaDados();
        }


        public void CarregaDados()
        {
            // Cria um datatable para receber o resultado

            DataTable dt = new DataTable();

            Agenda age = new Agenda();

            dt = age.SelecionarTodos();

            // Verifica se existem dados no DataTable

            if (dt.Rows.Count > 0)
            {
                // Cria um stringBuilder para construir a tabela
                StringBuilder html = new StringBuilder();

                //Cria tag table
                html.Append("<table class='table table-striped'>");

                html.Append("<thead class='thead-dark'>");

                html.Append("<tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<th>");
                    html.Append(column.ColumnName);
                    html.Append("</th>");
                }
                html.Append("</tr>");
                html.Append("</thead");

                //Cria linhas da tabela
                html.Append("<tbody>");
                foreach (DataRow row in dt.Rows)
                {
                    html.Append("<tr>");
                    foreach (DataColumn coloumn in dt.Columns)
                    {
                        html.Append("<td>");
                        html.Append(row[coloumn.ColumnName]);
                        html.Append("</td>");
                    }
                    html.Append("</tr>");
                    html.Append("</tbody>");
                }
                //Fecha a tabela
                html.Append("</table>");

                //Exibe a tabela na interface
                tabela.Text = html.ToString();


            }
        }

        protected void BtnGravar_ServerClick(object sender, EventArgs e)
        {
            Agenda ager = new Agenda();

            ager.nome = txtNome.Value;
            ager.email = txtEmail.Value;
            ager.fone = txtTelefone.Value;


            if (ager.GravaTelefone(ager))
            {
                menssagemSucesso.Attributes.CssStyle.Add("display", "block");

                CarregaDados();
            }
            else
                menssagemErro.Attributes.CssStyle.Add("display", "block");

        }

        protected void BtnEditar_ServerClick(object sender, EventArgs e)
        {

            Agenda ager = new Agenda();

            ager.nome = txtNome.Value;
            ager.email = txtEmailGerenciar.Value;
            ager.fone = txtTelefone.Value;

            if (ager.EditaTelefone(ager))
            {

                menssagemSucesso.Attributes.CssStyle.Add("display", "block");

                CarregaDados();
            }

            else
                menssagemErro.Attributes.CssStyle.Add("display", "block");
        }

        protected void BtnDelet_ServerClick(object sender, EventArgs e)
        {

            Agenda ager = new Agenda();
     
            ager.email = txtEmailGerenciar.Value;


            if (ager.DeleteTelefones(ager))
            {
                menssagemSucesso.Attributes.CssStyle.Add("display", "block");
                CarregaDados();
            }
            else
                menssagemErro.Attributes.CssStyle.Add("display", "block");
        }
    }
}