﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Npgsql;
using System.Data;

namespace AgendaTelefonica
{
    public class Agenda
    {

        public string nome { get; set; }
        public string email { get; set; }
        public string fone { get; set; }

        public bool GravaTelefone(Agenda age)
        {

            // Cria um objeto da classe conexao
            DbConnect db = new DbConnect();

            // Cria um objeto de comando do postgre
            NpgsqlCommand cmd = new NpgsqlCommand();

            try
            {

                // ADCIONA A INSTRUÇÃO SQL
                cmd.CommandText = "INSERT INTO telefones (nome, email, fone) values(@nome, @email, @fone)";

                // Desine os valores que serão passados para a intrução sql
                cmd.Parameters.AddWithValue("@nome", age.nome);
                cmd.Parameters.AddWithValue("@email", age.email);
                cmd.Parameters.AddWithValue("@fone", age.fone);

                // Cria uma conexao com o banco
                cmd.Connection = db.OpenConnection();

                // Executa o comando Sql
                cmd.ExecuteNonQuery();

                return true;

            }
            catch
            {
                return false;

            }
            finally
            {
                // Fecha a conexao com o banco
                db.CloseConnection(cmd.Connection);

            }
        }

        public DataTable SelecionarTodos()
        {
            DbConnect connect = new DbConnect();

            NpgsqlCommand comando = new NpgsqlCommand();

            comando.CommandText = "select * from telefones order by id";

            comando.Connection = connect.OpenConnection();

            DataTable dttelefones = new DataTable();

            dttelefones.Load(comando.ExecuteReader());

            connect.CloseConnection(comando.Connection);

            return dttelefones;


        }

        public bool EditaTelefone(Agenda age)
        {


            // Cria um objeto da classe conexao
            DbConnect db = new DbConnect();

            // Cria um objeto de comando do postgre
            NpgsqlCommand cmd = new NpgsqlCommand();

            try
            {

                // ADCIONA A INSTRUÇÃO SQL
                cmd.CommandText = @"update telefones set nome = @nome ,email = @email, fone = @fone where email = @email";

                // Desine os valores que serão passados para a intrução sql
                cmd.Parameters.AddWithValue("@nome", age.nome);
                cmd.Parameters.AddWithValue("@email", age.email);
                cmd.Parameters.AddWithValue("@fone", age.fone);

                // Cria uma conexao com o banco
                cmd.Connection = db.OpenConnection();

                // Executa o comando Sql
                cmd.ExecuteNonQuery();

                return true;

            }
            catch
            {
                return false;

            }
            finally
            {
                // Fecha a conexao com o banco
                db.CloseConnection(cmd.Connection);

            }
        }

        public bool DeleteTelefones(Agenda age)
        {
            // Cria um objeto da classe conexao
            DbConnect db = new DbConnect();

            // Cria um objeto de comando do postgre
            NpgsqlCommand cmd = new NpgsqlCommand();

            try
            {

                // ADCIONA A INSTRUÇÃO SQL
                cmd.CommandText = @"delete from telefones where email = @email";

                // Desine os valores que serão passados para a intrução sql
        
                cmd.Parameters.AddWithValue("@email", age.email);
              

                // Cria uma conexao com o banco
                cmd.Connection = db.OpenConnection();

                // Executa o comando Sql
                cmd.ExecuteNonQuery();

                return true;

            }
            catch
            {
                return false;

            }
            finally
            {
                // Fecha a conexao com o banco
                db.CloseConnection(cmd.Connection);

            }

        }

    }

}
