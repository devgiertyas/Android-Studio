﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using Npgsql;

namespace AgendaTelefonica
{
    public class DbConnect
    {
        // Método para criar a conexão com o banco
        public NpgsqlConnection OpenConnection()
        {
            // Leitura das credencias no app.config
            string host = ConfigurationManager.AppSettings["ConfigHost"];
            string user = ConfigurationManager.AppSettings["ConfigUser"];
            string pass = ConfigurationManager.AppSettings["ConfigPass"];
            string por = ConfigurationManager.AppSettings["ConfigPort"];
            string databasename = ConfigurationManager.AppSettings["ConfigDataBaseName"];

            // Cria a strind de conexão baseado nas credenciais lidas
            string connString = String.Format("Server ={0}; User Id= {1}; Database = {2}; Port = {3}; Password={4} ", host, user, databasename, por, pass);

            // Cria a conexão a partir da connection string 
            var conn = new NpgsqlConnection(connString);
            // Abre a conexão com o banco
            conn.Open();

            //Retorna a conexao aberta
            return conn;
        }
        // Método para fechar conexão com banco

        public void CloseConnection(NpgsqlConnection con)
        {
            con.Close();
        }

    }
}